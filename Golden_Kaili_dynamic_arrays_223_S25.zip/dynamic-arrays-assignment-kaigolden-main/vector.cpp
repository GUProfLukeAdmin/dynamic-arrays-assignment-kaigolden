#include <iostream>
#include <vector>

void part1() {
    std::vector<int> numbers;
    
    int maxElements = 50000; // limit on total number of added integers

    for(int i = 0; i < maxElements; i++) {
        numbers.push_back(rand());
    }
    std::cout << "After adding elements: Size = " << numbers.size() 
    << ", " << "Capacity = " << numbers.capacity() << std::endl;


    numbers.resize(numbers.size() / 2); // resize to half its original size
    std::cout << "After resizing: Size = " << numbers.size() 
    << ", " << "Capacity = " << numbers.capacity() << std::endl;


    numbers.shrink_to_fit(); // reduce capacity to fit the resized vector
    std::cout << "After shrink_to_fit(): Size = " << numbers.size() 
    << ", " << "Capacity = " << numbers.capacity() << std::endl;
}


void part2() {
    // initialize a bool vector & a char vector, each w/ 10k elements
    std::vector<bool> bools(10000);
    std::vector<char> chars(10000);

    // Calculate & print the memory usage of each vector in bytes

    int boolMemory = bools.size() * sizeof(bool);
    int charMemory = chars.size() * sizeof(char);

    std::cout << "Memory usage of std::vector<bool>: " 
    << boolMemory << " bytes" << std::endl;

    std::cout << "Memory usage of std::vector<char>: " 
    << charMemory << " bytes" << std::endl;
}

int main() {
    part1();
    part2();
    return 0;
}